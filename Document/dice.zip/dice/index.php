<?php
header('Location: www/dice/');
exit;
