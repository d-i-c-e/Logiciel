<?php

define('API_REST_ACCESS_GET_A_CARTE_OBJET', 'none');
define('API_REST_ACCESS_POST_A_CARTE_OBJET', 'none');
define('API_REST_ACCESS_PUT_A_CARTE_OBJET', 'none');
define('API_REST_ACCESS_DELETE_A_CARTE_OBJET', 'none');
define('API_REST_ACCESS_OPTIONS_A_CARTE_OBJET', 'all');
