<?php

define('API_REST_ACCESS_GET_CARTE', 'none');
define('API_REST_ACCESS_POST_CARTE', 'none');
define('API_REST_ACCESS_PUT_CARTE', 'none');
define('API_REST_ACCESS_DELETE_CARTE', 'none');
define('API_REST_ACCESS_OPTIONS_CARTE', 'all');
