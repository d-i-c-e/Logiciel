<?php

define('API_REST_ACCESS_GET_GROUPE', 'none');
define('API_REST_ACCESS_POST_GROUPE', 'none');
define('API_REST_ACCESS_PUT_GROUPE', 'none');
define('API_REST_ACCESS_DELETE_GROUPE', 'none');
define('API_REST_ACCESS_OPTIONS_GROUPE', 'all');
