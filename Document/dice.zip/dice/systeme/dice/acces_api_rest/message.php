<?php

define('API_REST_ACCESS_GET_MESSAGE', 'none');
define('API_REST_ACCESS_POST_MESSAGE', 'none');
define('API_REST_ACCESS_PUT_MESSAGE', 'none');
define('API_REST_ACCESS_DELETE_MESSAGE', 'none');
define('API_REST_ACCESS_OPTIONS_MESSAGE', 'all');
