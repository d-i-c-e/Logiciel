<?php

define('API_REST_ACCESS_GET_OBJET', 'none');
define('API_REST_ACCESS_POST_OBJET', 'none');
define('API_REST_ACCESS_PUT_OBJET', 'none');
define('API_REST_ACCESS_DELETE_OBJET', 'none');
define('API_REST_ACCESS_OPTIONS_OBJET', 'all');
