<?php

define('API_REST_ACCESS_GET_PARAMETRE', 'none');
define('API_REST_ACCESS_POST_PARAMETRE', 'none');
define('API_REST_ACCESS_PUT_PARAMETRE', 'none');
define('API_REST_ACCESS_DELETE_PARAMETRE', 'none');
define('API_REST_ACCESS_OPTIONS_PARAMETRE', 'all');
