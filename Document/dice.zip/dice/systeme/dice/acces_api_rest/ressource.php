<?php

define('API_REST_ACCESS_GET_RESSOURCE', 'none');
define('API_REST_ACCESS_POST_RESSOURCE', 'none');
define('API_REST_ACCESS_PUT_RESSOURCE', 'none');
define('API_REST_ACCESS_DELETE_RESSOURCE', 'none');
define('API_REST_ACCESS_OPTIONS_RESSOURCE', 'all');
