<?php

define('API_REST_ACCESS_GET_TYPE', 'none');
define('API_REST_ACCESS_POST_TYPE', 'none');
define('API_REST_ACCESS_PUT_TYPE', 'none');
define('API_REST_ACCESS_DELETE_TYPE', 'none');
define('API_REST_ACCESS_OPTIONS_TYPE', 'all');
