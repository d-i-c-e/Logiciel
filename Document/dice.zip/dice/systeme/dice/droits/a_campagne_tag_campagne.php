<?php

$mf_droits_defaut['a_campagne_tag_campagne__AJOUTER'] = false;
$mf_droits_defaut['a_campagne_tag_campagne__CREER'] = false;
$mf_droits_defaut['a_campagne_tag_campagne__MODIFIER'] = false;
$mf_droits_defaut['a_campagne_tag_campagne__SUPPRIMER'] = false;
$mf_droits_defaut['a_campagne_tag_campagne__DUPLIQUER'] = false;
$mf_droits_defaut['a_campagne_tag_campagne__FUSIONNER'] = false;

