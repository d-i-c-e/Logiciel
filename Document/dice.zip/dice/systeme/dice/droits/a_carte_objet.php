<?php

$mf_droits_defaut['a_carte_objet__AJOUTER'] = false;
$mf_droits_defaut['a_carte_objet__CREER'] = false;
$mf_droits_defaut['a_carte_objet__MODIFIER'] = false;
$mf_droits_defaut['a_carte_objet__SUPPRIMER'] = false;
$mf_droits_defaut['a_carte_objet__DUPLIQUER'] = false;
$mf_droits_defaut['a_carte_objet__FUSIONNER'] = false;

