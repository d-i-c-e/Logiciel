<?php

$mf_droits_defaut['a_joueur_parametre__AJOUTER'] = false;
$mf_droits_defaut['a_joueur_parametre__CREER'] = false;
$mf_droits_defaut['a_joueur_parametre__MODIFIER'] = false;
$mf_droits_defaut['a_joueur_parametre__SUPPRIMER'] = false;
$mf_droits_defaut['a_joueur_parametre__DUPLIQUER'] = false;
$mf_droits_defaut['a_joueur_parametre__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__a_joueur_parametre_Valeur_choisie'] = false;
$mf_droits_defaut['api_modifier__a_joueur_parametre_Actif'] = false;
