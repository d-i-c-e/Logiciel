<?php

$mf_droits_defaut['a_liste_contact_joueur__AJOUTER'] = false;
$mf_droits_defaut['a_liste_contact_joueur__CREER'] = false;
$mf_droits_defaut['a_liste_contact_joueur__MODIFIER'] = false;
$mf_droits_defaut['a_liste_contact_joueur__SUPPRIMER'] = false;
$mf_droits_defaut['a_liste_contact_joueur__DUPLIQUER'] = false;
$mf_droits_defaut['a_liste_contact_joueur__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__a_liste_contact_joueur_Date_creation'] = false;
