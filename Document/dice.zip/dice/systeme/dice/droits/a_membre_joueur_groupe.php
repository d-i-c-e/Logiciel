<?php

$mf_droits_defaut['a_membre_joueur_groupe__AJOUTER'] = false;
$mf_droits_defaut['a_membre_joueur_groupe__CREER'] = false;
$mf_droits_defaut['a_membre_joueur_groupe__MODIFIER'] = false;
$mf_droits_defaut['a_membre_joueur_groupe__SUPPRIMER'] = false;
$mf_droits_defaut['a_membre_joueur_groupe__DUPLIQUER'] = false;
$mf_droits_defaut['a_membre_joueur_groupe__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__a_membre_joueur_groupe_Surnom'] = false;
$mf_droits_defaut['api_modifier__a_membre_joueur_groupe_Grade'] = false;
$mf_droits_defaut['api_modifier__a_membre_joueur_groupe_Date_adhesion'] = false;
