<?php

$mf_droits_defaut['a_ressource_tag_ressource__AJOUTER'] = false;
$mf_droits_defaut['a_ressource_tag_ressource__CREER'] = false;
$mf_droits_defaut['a_ressource_tag_ressource__MODIFIER'] = false;
$mf_droits_defaut['a_ressource_tag_ressource__SUPPRIMER'] = false;
$mf_droits_defaut['a_ressource_tag_ressource__DUPLIQUER'] = false;
$mf_droits_defaut['a_ressource_tag_ressource__FUSIONNER'] = false;

