<?php

$mf_droits_defaut['campagne__AJOUTER'] = false;
$mf_droits_defaut['campagne__CREER'] = false;
$mf_droits_defaut['campagne__MODIFIER'] = false;
$mf_droits_defaut['campagne__SUPPRIMER'] = false;
$mf_droits_defaut['campagne__DUPLIQUER'] = false;
$mf_droits_defaut['campagne__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__campagne_Nom'] = false;
$mf_droits_defaut['api_modifier__campagne_Description'] = false;
$mf_droits_defaut['api_modifier__campagne_Image_Fichier'] = false;
$mf_droits_defaut['api_modifier__campagne_Nombre_joueur'] = false;
$mf_droits_defaut['api_modifier__campagne_Nombre_mj'] = false;
