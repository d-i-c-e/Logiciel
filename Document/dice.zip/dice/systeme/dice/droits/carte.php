<?php

$mf_droits_defaut['carte__AJOUTER'] = false;
$mf_droits_defaut['carte__CREER'] = false;
$mf_droits_defaut['carte__MODIFIER'] = false;
$mf_droits_defaut['carte__SUPPRIMER'] = false;
$mf_droits_defaut['carte__DUPLIQUER'] = false;
$mf_droits_defaut['carte__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__carte_Nom'] = false;
$mf_droits_defaut['api_modifier__carte_Hauteur'] = false;
$mf_droits_defaut['api_modifier__carte_Largeur'] = false;
$mf_droits_defaut['api_modifier__carte_Fichier'] = false;

$mf_droits_defaut['api_modifier_ref__carte__Code_groupe'] = false;
