<?php

$mf_droits_defaut['groupe__AJOUTER'] = false;
$mf_droits_defaut['groupe__CREER'] = false;
$mf_droits_defaut['groupe__MODIFIER'] = false;
$mf_droits_defaut['groupe__SUPPRIMER'] = false;
$mf_droits_defaut['groupe__DUPLIQUER'] = false;
$mf_droits_defaut['groupe__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__groupe_Nom'] = false;
$mf_droits_defaut['api_modifier__groupe_Description'] = false;
$mf_droits_defaut['api_modifier__groupe_Logo_Fichier'] = false;
$mf_droits_defaut['api_modifier__groupe_Effectif'] = false;
$mf_droits_defaut['api_modifier__groupe_Actif'] = false;
$mf_droits_defaut['api_modifier__groupe_Date_creation'] = false;
$mf_droits_defaut['api_modifier__groupe_Delai_suppression_jour'] = false;
$mf_droits_defaut['api_modifier__groupe_Suppression_active'] = false;

$mf_droits_defaut['api_modifier_ref__groupe__Code_campagne'] = false;
