<?php

$mf_droits_defaut['joueur__AJOUTER'] = false;
$mf_droits_defaut['joueur__CREER'] = false;
$mf_droits_defaut['joueur__MODIFIER'] = false;
$mf_droits_defaut['joueur__MODIFIER_PWD'] = false;
$mf_droits_defaut['joueur__SUPPRIMER'] = false;
$mf_droits_defaut['joueur__DUPLIQUER'] = false;
$mf_droits_defaut['joueur__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__joueur_Email'] = false;
$mf_droits_defaut['api_modifier__joueur_Identifiant'] = false;
$mf_droits_defaut['api_modifier__joueur_Password'] = false;
$mf_droits_defaut['api_modifier__joueur_Avatar_Fichier'] = false;
$mf_droits_defaut['api_modifier__joueur_Date_naissance'] = false;
$mf_droits_defaut['api_modifier__joueur_Date_inscription'] = false;
$mf_droits_defaut['api_modifier__joueur_Administrateur'] = false;
