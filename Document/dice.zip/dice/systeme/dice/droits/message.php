<?php

$mf_droits_defaut['message__AJOUTER'] = false;
$mf_droits_defaut['message__CREER'] = false;
$mf_droits_defaut['message__MODIFIER'] = false;
$mf_droits_defaut['message__SUPPRIMER'] = false;
$mf_droits_defaut['message__DUPLIQUER'] = false;
$mf_droits_defaut['message__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__message_Texte'] = false;
$mf_droits_defaut['api_modifier__message_Date'] = false;

$mf_droits_defaut['api_modifier_ref__message__Code_messagerie'] = false;
$mf_droits_defaut['api_modifier_ref__message__Code_joueur'] = false;
