<?php

$mf_droits_defaut['objet__AJOUTER'] = false;
$mf_droits_defaut['objet__CREER'] = false;
$mf_droits_defaut['objet__MODIFIER'] = false;
$mf_droits_defaut['objet__SUPPRIMER'] = false;
$mf_droits_defaut['objet__DUPLIQUER'] = false;
$mf_droits_defaut['objet__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__objet_Libelle'] = false;
$mf_droits_defaut['api_modifier__objet_Image_Fichier'] = false;

$mf_droits_defaut['api_modifier_ref__objet__Code_type'] = false;
