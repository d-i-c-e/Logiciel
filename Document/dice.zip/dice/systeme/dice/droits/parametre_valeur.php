<?php

$mf_droits_defaut['parametre_valeur__AJOUTER'] = false;
$mf_droits_defaut['parametre_valeur__CREER'] = false;
$mf_droits_defaut['parametre_valeur__MODIFIER'] = false;
$mf_droits_defaut['parametre_valeur__SUPPRIMER'] = false;
$mf_droits_defaut['parametre_valeur__DUPLIQUER'] = false;
$mf_droits_defaut['parametre_valeur__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__parametre_valeur_Libelle'] = false;

$mf_droits_defaut['api_modifier_ref__parametre_valeur__Code_parametre'] = false;
