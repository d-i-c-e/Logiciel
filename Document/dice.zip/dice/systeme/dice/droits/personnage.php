<?php

$mf_droits_defaut['personnage__AJOUTER'] = false;
$mf_droits_defaut['personnage__CREER'] = false;
$mf_droits_defaut['personnage__MODIFIER'] = false;
$mf_droits_defaut['personnage__SUPPRIMER'] = false;
$mf_droits_defaut['personnage__DUPLIQUER'] = false;
$mf_droits_defaut['personnage__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__personnage_Fichier_Fichier'] = false;
$mf_droits_defaut['api_modifier__personnage_Conservation'] = false;

$mf_droits_defaut['api_modifier_ref__personnage__Code_joueur'] = false;
$mf_droits_defaut['api_modifier_ref__personnage__Code_groupe'] = false;
