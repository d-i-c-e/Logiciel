<?php

$mf_droits_defaut['ressource__AJOUTER'] = false;
$mf_droits_defaut['ressource__CREER'] = false;
$mf_droits_defaut['ressource__MODIFIER'] = false;
$mf_droits_defaut['ressource__SUPPRIMER'] = false;
$mf_droits_defaut['ressource__DUPLIQUER'] = false;
$mf_droits_defaut['ressource__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__ressource_Nom'] = false;
