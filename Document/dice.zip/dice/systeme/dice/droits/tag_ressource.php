<?php

$mf_droits_defaut['tag_ressource__AJOUTER'] = false;
$mf_droits_defaut['tag_ressource__CREER'] = false;
$mf_droits_defaut['tag_ressource__MODIFIER'] = false;
$mf_droits_defaut['tag_ressource__SUPPRIMER'] = false;
$mf_droits_defaut['tag_ressource__DUPLIQUER'] = false;
$mf_droits_defaut['tag_ressource__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__tag_ressource_Libelle'] = false;
