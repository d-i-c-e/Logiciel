<?php

$mf_droits_defaut['type__AJOUTER'] = false;
$mf_droits_defaut['type__CREER'] = false;
$mf_droits_defaut['type__MODIFIER'] = false;
$mf_droits_defaut['type__SUPPRIMER'] = false;
$mf_droits_defaut['type__DUPLIQUER'] = false;
$mf_droits_defaut['type__FUSIONNER'] = false;

$mf_droits_defaut['api_modifier__type_Libelle'] = false;

$mf_droits_defaut['api_modifier_ref__type__Code_ressource'] = false;
