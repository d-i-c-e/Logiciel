<?php

class a_campagne_tag_campagne extends a_campagne_tag_campagne_monframework
{
}
