<?php

class a_candidature_joueur_groupe extends a_candidature_joueur_groupe_monframework
{
}
