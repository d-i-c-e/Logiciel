<?php

class a_carte_objet extends a_carte_objet_monframework
{
}
