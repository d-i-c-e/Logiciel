<?php

class a_invitation_joueur_groupe extends a_invitation_joueur_groupe_monframework
{
}
