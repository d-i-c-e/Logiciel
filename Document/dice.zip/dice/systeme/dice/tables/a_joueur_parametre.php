<?php

class a_joueur_parametre extends a_joueur_parametre_monframework
{
}
