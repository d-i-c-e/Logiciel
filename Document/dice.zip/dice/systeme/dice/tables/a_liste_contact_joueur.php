<?php

class a_liste_contact_joueur extends a_liste_contact_joueur_monframework
{
}
