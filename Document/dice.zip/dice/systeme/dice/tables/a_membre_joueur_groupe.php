<?php

class a_membre_joueur_groupe extends a_membre_joueur_groupe_monframework
{
}
