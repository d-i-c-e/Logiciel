<?php

class a_ressource_tag_ressource extends a_ressource_tag_ressource_monframework
{
}
