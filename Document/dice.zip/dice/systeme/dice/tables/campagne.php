<?php

class campagne extends campagne_monframework
{
}
