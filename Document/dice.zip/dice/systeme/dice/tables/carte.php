<?php

class carte extends carte_monframework
{
}
