<?php

class entite
{

}
