<?php

class groupe extends groupe_monframework
{
}
