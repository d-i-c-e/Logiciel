<?php

class joueur extends joueur_monframework
{
}
