<?php

class liste_contacts extends liste_contacts_monframework
{
}
