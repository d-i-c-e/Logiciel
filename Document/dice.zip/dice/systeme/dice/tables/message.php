<?php

class message extends message_monframework
{
}
