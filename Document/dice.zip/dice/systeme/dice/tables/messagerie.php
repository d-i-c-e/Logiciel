<?php

class messagerie extends messagerie_monframework
{
}
