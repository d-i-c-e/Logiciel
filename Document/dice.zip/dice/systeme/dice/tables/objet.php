<?php

class objet extends objet_monframework
{
}
