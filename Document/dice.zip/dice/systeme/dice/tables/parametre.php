<?php

class parametre extends parametre_monframework
{
}
