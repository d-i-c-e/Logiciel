<?php

class parametre_valeur extends parametre_valeur_monframework
{
}
