<?php

class personnage extends personnage_monframework
{
}
