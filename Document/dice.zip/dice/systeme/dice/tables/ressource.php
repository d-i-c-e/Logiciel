<?php

class ressource extends ressource_monframework
{
}
