<?php

class tag_campagne extends tag_campagne_monframework
{
}
