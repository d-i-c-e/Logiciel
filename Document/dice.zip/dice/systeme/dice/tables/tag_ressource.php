<?php

class tag_ressource extends tag_ressource_monframework
{
}
