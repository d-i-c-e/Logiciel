<?php

class type extends type_monframework
{
}
