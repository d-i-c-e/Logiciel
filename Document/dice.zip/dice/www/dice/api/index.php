<?php
header('Location: ../api.rest/');
exit();
?>
